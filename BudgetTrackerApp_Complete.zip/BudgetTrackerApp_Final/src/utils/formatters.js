export const formatCurrency = (amount) => {
  return `රු ${amount.toLocaleString('si-LK')}`;
};